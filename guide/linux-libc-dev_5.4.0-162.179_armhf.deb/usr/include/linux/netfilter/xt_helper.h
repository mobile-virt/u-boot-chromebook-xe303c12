/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _XT_HELPER_H
#define _XT_HELPER_H

struct xt_helper_info {
	int invert;
	char name[30];
};
#endif /* _XT_HELPER_H */
